from distutils.core import setup

setup(name='Restaurant',
      version='1.0',
      py_modules=['restaurant','internetrestaurant','xmlrestaurant','FindRes']
      )
